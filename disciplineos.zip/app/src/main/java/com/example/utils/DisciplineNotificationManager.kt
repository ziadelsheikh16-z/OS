package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

class DisciplineNotificationManager(private val context: Context) {
    companion object {
        private const val CHANNEL_ID = "discipline_tactical_alerts"
        private const val CHANNEL_NAME = "Tactical Directives"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Strict alerts and tactical reminder checkpoints from commander console"
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun sendNotification(title: String, message: String) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert) // high accessibility default dial icon
                .setContentTitle("DIRECTIVE: $title")
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            manager.notify(System.currentTimeMillis().toInt(), builder.build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun postTaskReminder(taskTitle: String, minutesRemaining: Int) {
        sendNotification(
            title = "TASK COMING DUE",
            message = "Execute objectives immediately. '$taskTitle' completes in $minutesRemaining min. Failure is unacceptable."
        )
    }

    fun postPenaltyAlert(taskTitle: String, penaltyAmount: Int) {
        sendNotification(
            title = "PENALTY REGISTERED",
            message = "Failed to complete '$taskTitle'. -$penaltyAmount points subducted from current rating."
        )
    }
}
