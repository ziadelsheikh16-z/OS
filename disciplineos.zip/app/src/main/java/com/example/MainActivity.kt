package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.DisciplineOSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DisciplineOSTheme {
                val navController = rememberNavController()
                val mainViewModel: DisciplineViewModel = viewModel()

                NavHost(
                    navController = navController,
                    startDestination = Screen.Splash.route
                ) {
                    composable(Screen.Splash.route) {
                        SplashScreen(
                            onNavigateNext = { onboarded ->
                                if (onboarded) {
                                    navController.navigate(Screen.Dashboard.route) {
                                        popUpTo(Screen.Splash.route) { inclusive = true }
                                    }
                                } else {
                                    navController.navigate(Screen.Onboarding.route) {
                                        popUpTo(Screen.Splash.route) { inclusive = true }
                                    }
                                }
                            },
                            viewModel = mainViewModel
                        )
                    }

                    composable(Screen.Onboarding.route) {
                        OnboardingScreen(
                            onOnboardComplete = {
                                navController.navigate(Screen.Dashboard.route) {
                                    popUpTo(Screen.Onboarding.route) { inclusive = true }
                                }
                            },
                            viewModel = mainViewModel
                        )
                    }

                    composable(Screen.Dashboard.route) {
                        DashboardScreen(
                            viewModel = mainViewModel,
                            onNavigateToRoutine = { id ->
                                navController.navigate(Screen.RoutineDetails.createRoute(id))
                            },
                            onNavigateToAddRoutine = {
                                navController.navigate(Screen.AddRoutine.route)
                            },
                            onNavigateToAddHabit = {
                                navController.navigate(Screen.AddHabit.route)
                            },
                            onNavigateToAnalytics = {
                                navController.navigate(Screen.Analytics.route)
                            },
                            onNavigateToAchievements = {
                                navController.navigate(Screen.Achievements.route)
                            },
                            onNavigateToSettings = {
                                navController.navigate(Screen.Settings.route)
                            }
                        )
                    }

                    composable(Screen.RoutineDetails.route) { backStackEntry ->
                        val routineIdStr = backStackEntry.arguments?.getString("routineId")
                        val routineId = routineIdStr?.toIntOrNull() ?: 1
                        RoutineDetailsScreen(
                            routineId = routineId,
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.AddRoutine.route) {
                        AddRoutineScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.AddHabit.route) {
                        AddHabitScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.Analytics.route) {
                        AnalyticsScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.Achievements.route) {
                        AchievementsScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.Settings.route) {
                        SettingsScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }
    }
}
