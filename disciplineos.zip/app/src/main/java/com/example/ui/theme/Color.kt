package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundBlack = Color(0xFF0A0B0D)
val SurfaceDark = Color(0xFF13151A)
val SurfaceAccent = Color(0xFF1E293B)
val DisplayWhite = Color(0xFFF1F5F9)
val TacticalGray = Color(0xFF64748B)

val ThreatRed = Color(0xFFEF4444)
val ThreatRedBg = Color(0xFF2A1215)

val SecureGreen = Color(0xFF10B981)
val SecureGreenBg = Color(0xFF0F2D24)

val WarningOrange = Color(0xFFF97316)
val WarningOrangeBg = Color(0xFF2E1C12)

val SteelyBorder = Color(0xFF1E293B)
