package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Dashboard : Screen("dashboard")
    object RoutineDetails : Screen("routine_details/{routineId}") {
        fun createRoute(routineId: Int) = "routine_details/$routineId"
    }
    object AddRoutine : Screen("add_routine")
    object AddHabit : Screen("add_habit")
    object Analytics : Screen("analytics")
    object Achievements : Screen("achievements")
    object Settings : Screen("settings")
}
