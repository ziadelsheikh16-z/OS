package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StrictDarkColorScheme = darkColorScheme(
    primary = DisplayWhite,
    secondary = TacticalGray,
    tertiary = ThreatRed,
    background = BackgroundBlack,
    surface = SurfaceDark,
    surfaceVariant = SurfaceAccent,
    onPrimary = BackgroundBlack,
    onSecondary = DisplayWhite,
    onTertiary = DisplayWhite,
    onBackground = DisplayWhite,
    onSurface = DisplayWhite,
    onSurfaceVariant = DisplayWhite,
    outline = SteelyBorder,
    error = ThreatRed
)

@Composable
fun DisciplineOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StrictDarkColorScheme,
        typography = Typography,
        content = content
    )
}
