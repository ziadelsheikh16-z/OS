package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.*
import com.example.ui.components.*
import com.example.ui.theme.*
import androidx.compose.ui.geometry.Offset
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(
    onNavigateNext: (Boolean) -> Unit,
    viewModel: DisciplineViewModel
) {
    val onboarded by viewModel.onboarded.collectAsState()
    var displayMessage by remember { mutableStateOf("INITIALIZING COMBAT CORE...") }

    LaunchedEffect(Unit) {
        delay(600)
        displayMessage = "CALIBRATING COHESION MULTIPLIERS..."
        delay(600)
        displayMessage = "SYNCHRONIZING DIGITAL COMMANDER CONSOLE..."
        delay(600)
        onNavigateNext(onboarded)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Tactical Shield",
                tint = DisplayWhite,
                modifier = Modifier
                    .size(90.dp)
                    .border(2.dp, SteelyBorder, RoundedCornerShape(45.dp))
                    .padding(16.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "DISCIPLINE OS",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = DisplayWhite,
                letterSpacing = 4.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "COHESION THROUGH CONSTANT COMPLIANCE",
                style = MaterialTheme.typography.labelSmall,
                color = TacticalGray,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(48.dp))
            Text(
                text = displayMessage,
                style = MaterialTheme.typography.labelLarge,
                color = WarningOrange,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .width(180.dp)
                    .height(2.dp),
                color = DisplayWhite,
                trackColor = SteelyBorder
            )
        }
    }
}

// ==========================================
// 2. ONBOARDING SCREEN
// ==========================================
@Composable
fun OnboardingScreen(
    onOnboardComplete: () -> Unit,
    viewModel: DisciplineViewModel
) {
    var strictSelected by remember { mutableStateOf(true) }
    var selectedRankGoal by remember { mutableStateOf("DISCIPLINED") }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Spacer(modifier = Modifier.height(30.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Terminal, contentDescription = "Terminal Icon", tint = WarningOrange)
                    Text(
                        text = " COMMANDER REGISTER",
                        style = MaterialTheme.typography.titleLarge,
                        color = DisplayWhite,
                        letterSpacing = 2.sp
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                TacticalDivider()
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "Welcome to DisciplineOS.\nThis is not a supportive, cozy tracker. This app is designed to enforce physical and psychological compliance. There are no excuses tolerated.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = DisplayWhite,
                    fontFamily = FontFamily.SansSerif,
                    lineHeight = 22.sp
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Active Choice parameters
                Text(
                    text = "STRICT ROUTINE ENFORCEMENT",
                    style = MaterialTheme.typography.labelMedium,
                    color = TacticalGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { strictSelected = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (strictSelected) ThreatRedBg else SurfaceDark,
                            contentColor = DisplayWhite
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, if (strictSelected) ThreatRed else SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Text("ON / SEQUENTIAL", style = MaterialTheme.typography.labelLarge)
                    }
                    Button(
                        onClick = { strictSelected = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!strictSelected) SurfaceAccent else SurfaceDark,
                            contentColor = TacticalGray
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, if (!strictSelected) DisplayWhite else SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Text("OFF / FREEFORM", style = MaterialTheme.typography.labelLarge)
                    }
                }
                Text(
                    text = if (strictSelected) 
                        "CRITICAL: Sequentially forces routine locks. You cannot skip or execute out-of-order tasks. Missing deadlines subducts points." 
                        else "No locks. Free tracking, but streaks expire on routine non-completion.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (strictSelected) WarningOrange else TacticalGray,
                    modifier = Modifier.padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "TARGET RESILIENCE THRESHOLD",
                    style = MaterialTheme.typography.labelMedium,
                    color = TacticalGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                listOf("FOCUSED", "DISCIPLINED", "MONSTER DISCIPLINE").forEach { rank ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(if (selectedRankGoal == rank) SurfaceAccent else SurfaceDark, RoundedCornerShape(12.dp))
                            .border(1.dp, if (selectedRankGoal == rank) SecureGreen else SteelyBorder, RoundedCornerShape(12.dp))
                            .clickable { selectedRankGoal = rank }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(rank, style = MaterialTheme.typography.titleMedium, color = DisplayWhite)
                        RadioButton(
                            selected = selectedRankGoal == rank,
                            onClick = { selectedRankGoal = rank },
                            colors = RadioButtonDefaults.colors(selectedColor = SecureGreen, unselectedColor = TacticalGray)
                        )
                    }
                }
            }

            Button(
                onClick = {
                    scope.launch {
                        viewModel.updateSystemSettings(
                            strictMode = strictSelected,
                            severity = if (selectedRankGoal == "MONSTER DISCIPLINE") "SEVERE" else "MEDIUM",
                            multiplier = if (selectedRankGoal == "MONSTER DISCIPLINE") 1.5f else 1.0f,
                            forceReset = false
                        )
                        viewModel.completeOnboarding()
                        onOnboardComplete()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DisplayWhite, contentColor = BackgroundBlack),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .border(1.dp, SteelyBorder, RoundedCornerShape(16.dp))
            ) {
                Text(
                    text = "INITIALIZE WARRIOR ENVIRONMENT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

// ==========================================
// 3. DASHBOARD SCREEN
// ==========================================
@Composable
fun DashboardScreen(
    viewModel: DisciplineViewModel,
    onNavigateToRoutine: (Int) -> Unit,
    onNavigateToAddRoutine: () -> Unit,
    onNavigateToAddHabit: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToAchievements: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val score by viewModel.disciplineScore.collectAsState()
    val streak by viewModel.currentStreak.collectAsState()
    val extremeStrict by viewModel.extremeStrictMode.collectAsState()
    val routines by viewModel.allRoutines.collectAsState()
    val habits by viewModel.allHabits.collectAsState()
    val statsList by viewModel.allDailyStats.collectAsState()
    val uiMsg by viewModel.uiMessage.collectAsState()

    val level = viewModel.calculateDisciplineLevel(score)
    val motivation = viewModel.getMotivationalMessage(level, score, 1f)

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(uiMsg) {
        uiMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUiMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DISCIPLINE_OS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = "SYS_STATUS: ADHERENT",
                            style = MaterialTheme.typography.labelSmall,
                            color = SecureGreen
                        )
                    }
                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = DisplayWhite)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // General Command Readout banner
            item {
                TacticalCard(
                    borderColor = if (score < 250) ThreatRed else SteelyBorder
                ) {
                    Text(
                        text = "DIRECTIVE REPORT",
                        style = MaterialTheme.typography.labelSmall,
                        color = TacticalGray,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = motivation.first,
                        style = MaterialTheme.typography.titleLarge,
                        color = if (score < 250) ThreatRed else DisplayWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = motivation.second,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TacticalGray
                    )
                }
            }

            // Core Score Gauge and Stats Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Gauge left
                    DisciplineScoreIndicator(score = score, modifier = Modifier.weight(1.1f))

                    // Tactical values panel right
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Stat box streak
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceDark, RoundedCornerShape(16.dp))
                                .border(1.dp, SteelyBorder, RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("COMPLIANCE STREAK", style = MaterialTheme.typography.labelSmall, color = TacticalGray, fontSize = 8.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.LocalFireDepartment, contentDescription = "Streak", tint = SecureGreen, modifier = Modifier.size(16.dp))
                                    Text(" $streak DAYS", style = MaterialTheme.typography.titleMedium, color = SecureGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Stat box strict
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceDark, RoundedCornerShape(16.dp))
                                .border(1.dp, if (extremeStrict) ThreatRed else SteelyBorder, RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("SEQUENTIAL LOCKS", style = MaterialTheme.typography.labelSmall, color = TacticalGray, fontSize = 8.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (extremeStrict) Icons.Default.Lock else Icons.Default.LockOpen,
                                        contentDescription = "LocksStatus",
                                        tint = if (extremeStrict) ThreatRed else TacticalGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (extremeStrict) " ACTIVE" else " BYPASSED",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (extremeStrict) ThreatRed else TacticalGray,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Github Heatmap Calendar
            item {
                HeatmapCalendar(statsList = statsList)
            }

            // Core Routine Checklist list
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OPERATIONAL ROUTINES",
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 1.sp,
                        color = TacticalGray
                    )
                    IconButton(
                        onClick = onNavigateToAddRoutine,
                        modifier = Modifier.size(34.dp).border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Routine", tint = DisplayWhite, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (routines.isEmpty()) {
                item {
                    TacticalCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "NO ROUTINE TASKS LOADED IN SYSTEM CORES.",
                            color = WarningOrange,
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.triggerManualPresetSeed() },
                            colors = ButtonDefaults.buttonColors(containerColor = DisplayWhite, contentColor = BackgroundBlack),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Text("DEPLOY PRESET ROUTINES")
                        }
                    }
                }
            } else {
                items(routines) { routine ->
                    TacticalCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = if (routine.isCompletedToday) SecureGreen else SteelyBorder,
                        onClick = { onNavigateToRoutine(routine.id) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(if (routine.isCompletedToday) SecureGreen else WarningOrange)
                                    )
                                    Text(
                                        text = " ${routine.name.uppercase()}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = DisplayWhite
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Category: ${routine.category} | Strict: ${if (routine.isStrict) "ON" else "OFF"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TacticalGray
                                )
                            }
                            Icon(
                                imageVector = if (routine.isCompletedToday) Icons.Default.CheckCircle else Icons.Default.ArrowForward,
                                contentDescription = "Open Routine",
                                tint = if (routine.isCompletedToday) SecureGreen else DisplayWhite
                            )
                        }
                    }
                }
            }

            // Bad Habit execution triggers shortcut panel
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INCIDENT TRACER (SLIP-UPS)",
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 1.sp,
                        color = TacticalGray
                    )
                    IconButton(
                        onClick = onNavigateToAddHabit,
                        modifier = Modifier.size(34.dp).border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Habit", tint = DisplayWhite, modifier = Modifier.size(18.dp))
                    }
                }
            }

            if (habits.isEmpty()) {
                item {
                    Text("No habits populated.", style = MaterialTheme.typography.bodySmall, color = TacticalGray)
                }
            } else {
                items(habits) { habit ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceDark, RoundedCornerShape(12.dp))
                            .border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(habit.name, style = MaterialTheme.typography.titleMedium, color = DisplayWhite)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Deduction: -${habit.penaltyPoints} Rating Points | Tracked: ${habit.timesViolatedToday} today",
                                style = MaterialTheme.typography.bodySmall,
                                color = ThreatRed
                            )
                        }
                        Button(
                            onClick = { viewModel.logHabitIncident(habit) },
                            colors = ButtonDefaults.buttonColors(containerColor = ThreatRedBg, contentColor = ThreatRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.border(1.dp, ThreatRed, RoundedCornerShape(12.dp))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = "Violator", modifier = Modifier.size(14.dp))
                                Text(" VIOLATED", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            // Quick Nav Dashboard shortcuts panel at bottom
            item {
                Spacer(modifier = Modifier.height(8.dp))
                TacticalDivider()
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "COMMAND TERMINAL SHORTCUTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TacticalGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onNavigateToAnalytics,
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, SteelyBorder, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = DisplayWhite)
                    ) {
                        Icon(imageVector = Icons.Default.Analytics, contentDescription = "Analytics", modifier = Modifier.size(16.dp))
                        Text(" HIST_DATA", style = MaterialTheme.typography.labelSmall)
                    }
                    Button(
                        onClick = onNavigateToAchievements,
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, SteelyBorder, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = DisplayWhite)
                    ) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = "Achievements", modifier = Modifier.size(16.dp))
                        Text(" MEDALS", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. ROUTINE DETAILS SCREEN
// ==========================================
@Composable
fun RoutineDetailsScreen(
    routineId: Int,
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    val routines by viewModel.allRoutines.collectAsState()
    val routine = routines.find { it.id == routineId }
    val localTasks by remember(routineId) {
        viewModel.getTasksForRoutine(routineId)
    }.collectAsState(initial = emptyList<RoutineTask>())

    val uiMsg by viewModel.uiMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiMsg) {
        uiMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUiMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = DisplayWhite)
                    }
                    Text(
                        text = (routine?.name ?: "ROUTINE_INSPECT").uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = { routine?.let { viewModel.deleteRoutine(it); onNavigateBack() } },
                        modifier = Modifier.border(1.dp, ThreatRed.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = ThreatRed)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            if (routine == null) {
                Text("Routine not found or deleted.", color = ThreatRed, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("ROUTINE CATEGORY", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                        Text(routine.category.uppercase(), style = MaterialTheme.typography.titleMedium, color = DisplayWhite)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("STRICT SEQUENCING", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                        Text(
                            text = if (routine.isStrict) "CONSTRAINED_LOCK" else "UNLOCKED",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (routine.isStrict) ThreatRed else TacticalGray
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                TacticalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "SEQUENCE PROGRESS CHECKLIST",
                    style = MaterialTheme.typography.labelMedium,
                    color = TacticalGray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (localTasks.isEmpty()) {
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text("No objectives logged inside directive.", style = MaterialTheme.typography.bodyLarge, color = WarningOrange, fontFamily = FontFamily.Monospace)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(localTasks) { task ->
                            // In strict mode, determine locks. Wait, if sequential lock and prior is incomplete, it is locked.
                            val isLocked = remember(localTasks, task) {
                                routine.isStrict && localTasks.any { it.orderIndex < task.orderIndex && !it.isCompletedToday }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isLocked) SurfaceDark.copy(alpha = 0.5f) else SurfaceDark)
                                    .border(1.dp, if (task.isCompletedToday) SecureGreen else if (isLocked) SteelyBorder.copy(alpha = 0.5f) else SteelyBorder)
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = when(task.iconName) {
                                                "bed" -> Icons.Default.Bed
                                                "fitness_center" -> Icons.Default.FitnessCenter
                                                "computer" -> Icons.Default.Computer
                                                "analytics" -> Icons.Default.Analytics
                                                "rate_review" -> Icons.Default.RateReview
                                                else -> Icons.Default.Assignment
                                            },
                                            contentDescription = "Task Icon",
                                            tint = if (task.isCompletedToday) SecureGreen else if (isLocked) TacticalGray else WarningOrange,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = "  ${task.title}",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (isLocked) TacticalGray else DisplayWhite,
                                            textDecoration = if (task.isCompletedToday) TextDecoration.LineThrough else TextDecoration.None
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Time: ${task.durationMinutes}m | Deadline: ${task.deadlineTime} | Reward: +${task.pointsReward}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TacticalGray
                                    )
                                }

                                if (isLocked) {
                                    Icon(imageVector = Icons.Default.Lock, contentDescription = "Locked task", tint = ThreatRed)
                                } else {
                                    Checkbox(
                                        checked = task.isCompletedToday,
                                        onCheckedChange = { viewModel.toggleTaskCompletion(task, it) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = SecureGreen,
                                            uncheckedColor = TacticalGray,
                                            checkmarkColor = BackgroundBlack
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. ADD ROUTINE SYSTEM
// ==========================================
@Composable
fun AddRoutineScreen(
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Morning Ritual") }
    var strictMode by remember { mutableStateOf(true) }

    // Dynamic tasks list builders
    var task1Title by remember { mutableStateOf("") }
    var task1Min by remember { mutableStateOf("15") }
    var task1Pts by remember { mutableStateOf("15") }

    var task2Title by remember { mutableStateOf("") }
    var task2Min by remember { mutableStateOf("30") }
    var task2Pts by remember { mutableStateOf("30") }

    Scaffold(
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = DisplayWhite)
                    }
                    Text("ADD DIRECTIVE RULE", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("DIRECTIVE HEADER PARAMETERS", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Directive Designation Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = DisplayWhite,
                        unfocusedTextColor = DisplayWhite,
                        focusedBorderColor = DisplayWhite,
                        unfocusedBorderColor = SteelyBorder,
                        focusedLabelColor = DisplayWhite,
                        unfocusedLabelColor = TacticalGray
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            item {
                Text("TACTICAL CATEGORY", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Morning Ritual", "Focus Ritual", "Rest Execution").forEach { cat ->
                        Button(
                            onClick = { category = cat },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (category == cat) SurfaceAccent else SurfaceDark,
                                contentColor = DisplayWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, if (category == cat) DisplayWhite else SteelyBorder, RoundedCornerShape(12.dp))
                        ) {
                            Text(cat.substringBefore(" "), fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("STRICT ORDER LOCKS", style = MaterialTheme.typography.titleMedium, color = DisplayWhite)
                        Text("Enforce out-of-order locks and skipped-task penalties", style = MaterialTheme.typography.bodySmall, color = TacticalGray)
                    }
                    Switch(
                        checked = strictMode,
                        onCheckedChange = { strictMode = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = SecureGreen, checkedTrackColor = SecureGreenBg)
                    )
                }
            }

            item {
                TacticalDivider()
                Spacer(modifier = Modifier.height(4.dp))
                Text("OBJECTIVE CHECKPOINT #1", style = MaterialTheme.typography.labelSmall, color = WarningOrange)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = task1Title,
                    onValueChange = { task1Title = it },
                    label = { Text("Task Title Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = task1Min,
                        onValueChange = { task1Min = it },
                        label = { Text("Duration (m)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = task1Pts,
                        onValueChange = { task1Pts = it },
                        label = { Text("Reward Points") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("OBJECTIVE CHECKPOINT #2 (OPTIONAL)", style = MaterialTheme.typography.labelSmall, color = WarningOrange)
                Spacer(modifier = Modifier.height(6.dp))

                 OutlinedTextField(
                    value = task2Title,
                    onValueChange = { task2Title = it },
                    label = { Text("Task Title Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = task2Min,
                        onValueChange = { task2Min = it },
                        label = { Text("Duration (m)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = task2Pts,
                        onValueChange = { task2Pts = it },
                        label = { Text("Reward Points") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        if (name.isNotEmpty() && task1Title.isNotEmpty()) {
                            val taskList = mutableListOf<Triple<String, Int, Int>>()
                            taskList.add(Triple(task1Title, task1Min.toIntOrNull() ?: 15, task1Pts.toIntOrNull() ?: 15))
                            if (task2Title.isNotEmpty()) {
                                taskList.add(Triple(task2Title, task2Min.toIntOrNull() ?: 30, task2Pts.toIntOrNull() ?: 30))
                            }

                            viewModel.createRoutine(
                                name = name,
                                activeDays = "Mon,Tue,Wed,Thu,Fri,Sat,Sun",
                                category = category,
                                isStrict = strictMode,
                                tasksList = taskList
                            )
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DisplayWhite, contentColor = BackgroundBlack),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .padding(bottom = 24.dp)
                ) {
                    Text("DEPLOY DIRECTIVE PROCESS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 6. ADD BAD HABIT SCREEN
// ==========================================
@Composable
fun AddHabitScreen(
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var penaltyAmt by remember { mutableStateOf("25") }
    var category by remember { mutableStateOf("Wasting Time") }

    Scaffold(
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = DisplayWhite)
                    }
                    Text("ENROLL REBELLIOUS SLIP", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column {
                Text("HABIT DESIGNATION TITLE", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("E.g. Pornography, Smoking, Social Media Scrolling") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Column {
                Text("PENALALIZATION INTENSITY", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = penaltyAmt,
                    onValueChange = { penaltyAmt = it },
                    label = { Text("Penalty Point Deduct Value (Positive Int)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DisplayWhite, unfocusedBorderColor = SteelyBorder),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Column {
                Text("SLIP CLASSIFICATION", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Wasting Time", "Health Slip", "Defiance").forEach { cat ->
                        Button(
                            onClick = { category = cat },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (category == cat) SurfaceAccent else SurfaceDark,
                                contentColor = DisplayWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, if (category == cat) DisplayWhite else SteelyBorder, RoundedCornerShape(12.dp))
                        ) {
                            Text(cat.substringBefore(" "), fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (name.isNotEmpty()) {
                        viewModel.createHabit(
                            name = name,
                            penaltyPoints = penaltyAmt.toIntOrNull() ?: 25,
                            category = category
                        )
                        onNavigateBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ThreatRed, contentColor = DisplayWhite),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .border(1.dp, ThreatRed, RoundedCornerShape(16.dp))
            ) {
                Text("INTEGRATE SUBVERSION MONITORING", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 7. HISTORICAL ANALYTICS SYSTEM (CUSTOM CHART)
// ==========================================
@Composable
fun AnalyticsScreen(
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    val statsList by viewModel.allDailyStats.collectAsState()
    val penalties by viewModel.allPenalties.collectAsState()

    Scaffold(
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = DisplayWhite)
                    }
                    Text("TACTICAL INTEL REPORT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "DISCIPLINE INDEX VECTOR (RECENT STABILITY)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TacticalGray
                )
                Spacer(modifier = Modifier.height(10.dp))

                val linePoints = remember(statsList) {
                    statsList.take(7).reversed().map { stat -> stat.score.toFloat() }
                }

                TacticalCard(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                    if (linePoints.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Awaiting historical cycle calibration logs...", color = WarningOrange, fontFamily = FontFamily.Monospace)
                        }
                    } else {
                        // Custom Canvas Line chart to avoid compile or render bugs
                        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                            val maxVal: Float = linePoints.maxOrNull()?.coerceAtLeast(300f) ?: 500f
                            val widthInterval: Float = size.width / (linePoints.size - 1).coerceAtLeast(1)
                            
                            // Draw Grid Lines representing rating levels
                            for (grid in 1..4) {
                                val gridY = size.height * (grid / 4f)
                                drawLine(
                                    color = SteelyBorder.copy(alpha = 0.4f),
                                    start = Offset(0f, gridY),
                                    end = Offset(size.width, gridY),
                                    strokeWidth = 1f
                                )
                            }

                            val drawPoints: List<Offset> = linePoints.mapIndexed { idx: Int, value: Float ->
                                val x: Float = idx * widthInterval
                                val y: Float = size.height - ((value / maxVal) * size.height).coerceIn(0f, size.height)
                                Offset(x, y)
                            }

                            // Draw graphical path
                            for (i in 0 until drawPoints.size - 1) {
                                drawLine(
                                    color = SecureGreen,
                                    start = drawPoints[i],
                                    end = drawPoints[i + 1],
                                    strokeWidth = 4f
                                )
                                drawCircle(
                                    color = DisplayWhite,
                                    radius = 5f,
                                    center = drawPoints[i]
                                )
                            }
                            drawCircle(
                                color = DisplayWhite,
                                radius = 5f,
                                center = drawPoints.last()
                            )
                        }
                    }
                }
            }

            item {
                Text("HISTORIC BREACH AUDIT LOG", style = MaterialTheme.typography.labelMedium, color = TacticalGray)
            }

            if (penalties.isEmpty()) {
                item {
                    Text("NO DEFICIENCY INCIDENTS REGISTERED. STATUS EXCELLENT.", color = SecureGreen, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                }
            } else {
                items(penalties) { log: PenaltyLog ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceDark)
                            .border(1.dp, SteelyBorder)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("BREACH: ${log.reason}", style = MaterialTheme.typography.bodyMedium, color = DisplayWhite)
                            val datetime = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(log.timestamp))
                            Text("Incident Stamp: $datetime", style = MaterialTheme.typography.bodySmall, color = TacticalGray)
                        }
                        Text("-${log.pointsDeducted} PTS", style = MaterialTheme.typography.titleMedium, color = ThreatRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 8. MILITARY ACHIEVEMENTS SCREEN
// ==========================================
@Composable
fun AchievementsScreen(
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    val achievements by viewModel.allAchievements.collectAsState()

    Scaffold(
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = DisplayWhite)
                    }
                    Text("WARROOM ADHERENCE BADGES", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(achievements) { badge ->
                TacticalCard(
                    borderColor = if (badge.isUnlocked) SecureGreen else SteelyBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = when(badge.iconName) {
                                "star" -> Icons.Default.Star
                                "shield" -> Icons.Default.Shield
                                "lock" -> Icons.Default.Lock
                                "military_tech" -> Icons.Default.MilitaryTech
                                "bolt" -> Icons.Default.OfflineBolt
                                else -> Icons.Default.WorkspacePremium
                            },
                            contentDescription = badge.title,
                            tint = if (badge.isUnlocked) SecureGreen else TacticalGray.copy(alpha = 0.3f),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = badge.title.uppercase(),
                            style = MaterialTheme.typography.titleMedium,
                            color = if (badge.isUnlocked) DisplayWhite else TacticalGray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = badge.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TacticalGray,
                            textAlign = TextAlign.Center,
                            fontSize = 11.sp,
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (badge.isUnlocked) "UNLOCKED SECURE" else "LOCKED INERT",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (badge.isUnlocked) SecureGreen else TacticalGray,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 9. CONTROL PANEL / SETTINGS
// ==========================================
@Composable
fun SettingsScreen(
    viewModel: DisciplineViewModel,
    onNavigateBack: () -> Unit
) {
    val strictMode by viewModel.extremeStrictMode.collectAsState()
    val severity by viewModel.punishmentSeverity.collectAsState()
    val multiplier by viewModel.rewardMultiplier.collectAsState()
    var displayResetConfirm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = BackgroundBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.border(1.dp, SteelyBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = DisplayWhite)
                    }
                    Text("SYSTEM CALIBRATION", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(12.dp))
                TacticalDivider()
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column {
                Text("COHESION INTENSITY ADJUSTER", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("LOW", "MEDIUM", "SEVERE").forEach { sev ->
                        Button(
                            onClick = { viewModel.updateSystemSettings(strictMode, sev, multiplier, false) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (severity == sev) ThreatRedBg else SurfaceDark,
                                contentColor = DisplayWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, if (severity == sev) ThreatRed else SteelyBorder, RoundedCornerShape(12.dp))
                        ) {
                            Text(sev, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("GLOBAL STRICT BLOCKS", style = MaterialTheme.typography.titleMedium, color = DisplayWhite)
                    Text("Lock all subsequent tasks until previous in-bounds complete.", style = MaterialTheme.typography.bodySmall, color = TacticalGray)
                }
                Switch(
                    checked = strictMode,
                    onCheckedChange = { viewModel.updateSystemSettings(it, severity, multiplier, false) },
                    colors = SwitchDefaults.colors(checkedThumbColor = SecureGreen, checkedTrackColor = SecureGreenBg)
                )
            }

            Column {
                Text("REWARD SCALE MULTIPLIER", style = MaterialTheme.typography.labelSmall, color = TacticalGray)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 1.0f, 1.5f).forEach { mult ->
                        Button(
                            onClick = { viewModel.updateSystemSettings(strictMode, severity, mult, false) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (multiplier == mult) SurfaceAccent else SurfaceDark,
                                contentColor = DisplayWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, if (multiplier == mult) DisplayWhite else SteelyBorder, RoundedCornerShape(12.dp))
                        ) {
                            Text("${mult}x", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { displayResetConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = ThreatRedBg, contentColor = ThreatRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .border(1.dp, ThreatRed, RoundedCornerShape(16.dp))
            ) {
                Text("PURGE DATABASE & RE-CALIBRATE OS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            if (displayResetConfirm) {
                AlertDialog(
                    onDismissRequest = { displayResetConfirm = false },
                    containerColor = BackgroundBlack,
                    title = { Text("CONFIRM DESTRUCTIVE PURGE", color = ThreatRed, fontFamily = FontFamily.Monospace) },
                    text = { Text("Warning. This registers full destructive purge parameter. All records, scores, streaks, routines, habits delete forever. Agree to clean slate?", color = DisplayWhite) },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.updateSystemSettings(strictMode = true, severity = "MEDIUM", multiplier = 1.0f, forceReset = true)
                                displayResetConfirm = false
                                onNavigateBack()
                            }
                        ) {
                            Text("EXECUTE PURGE", color = ThreatRed, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { displayResetConfirm = false }) {
                            Text("ABORT REPORT", color = DisplayWhite)
                        }
                    }
                )
            }
        }
    }
}
