package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Calendar

// Reusable military bordered card
@Composable
fun TacticalCard(
    modifier: Modifier = Modifier,
    borderColor: Color = MaterialTheme.colorScheme.outline,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .then(
                if (onClick != null) {
                    Modifier.clickableWithRipple(onClick = onClick)
                } else Modifier
            )
            .padding(14.dp)
    ) {
        Column {
            content()
        }
    }
}

// Special Modifier utility to support clean visual ripples while maintaining aesthetic
@Composable
fun Modifier.clickableWithRipple(onClick: () -> Unit): Modifier {
    return this.clickable(onClick = onClick)
}

// Military scan divider
@Composable
fun TacticalDivider(
    modifier: Modifier = Modifier,
    color: Color = SteelyBorder,
    thickness: Dp = 1.dp
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(thickness)
    ) {
        drawLine(
            color = color,
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            strokeWidth = thickness.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
        )
    }
}

// Circular custom score indicator
@Composable
fun DisciplineScoreIndicator(
    score: Int,
    modifier: Modifier = Modifier
) {
    val level = when {
        score < 100 -> "WEAK"
        score < 250 -> "UNSTABLE"
        score < 500 -> "AVERAGE"
        score < 800 -> "FOCUSED"
        score < 1200 -> "DISCIPLINED"
        else -> "MONSTER"
    }

    val stateColor = when {
        score < 250 -> ThreatRed
        score < 500 -> WarningOrange
        else -> SecureGreen
    }

    val animatedProgress = remember { Animatable(0f) }
    LaunchedEffect(score) {
        val target = (score.toFloat() / 1500f).coerceIn(0.1f, 1f)
        animatedProgress.animateTo(
            targetValue = target,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
    }

    Box(
        modifier = modifier.size(150.dp),
        contentAlignment = Alignment.Center
    ) {
        // Glowing Background brush circle
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = stateColor.copy(alpha = 0.05f),
                radius = size.minDimension / 2
            )
            // Empty background arc
            drawArc(
                color = SteelyBorder.copy(alpha = 0.3f),
                startAngle = -225f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 8.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f), 0f))
            )
            // Animated positive progress arc
            drawArc(
                color = stateColor,
                startAngle = -225f,
                sweepAngle = 270f * animatedProgress.value,
                useCenter = false,
                style = Stroke(width = 10.dp.toPx())
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "RATING",
                style = MaterialTheme.typography.labelSmall,
                color = TacticalGray,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = score.toString(),
                style = MaterialTheme.typography.displayMedium,
                color = DisplayWhite,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = level,
                style = MaterialTheme.typography.labelSmall,
                color = stateColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// 28-day Heatmap glowing block grid matching classic github-commit view style
@Composable
fun HeatmapCalendar(
    statsList: List<com.example.database.DailyStats>,
    modifier: Modifier = Modifier
) {
    // Generate recent 28 days
    val dates = remember(statsList) {
        val list = mutableListOf<Pair<String, Int>>()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -27)
        for (i in 0 until 28) {
            val key = sdf.format(cal.time)
            val dayStat = statsList.find { it.date == key }
            val score = dayStat?.score ?: 100 // default initial baseline
            list.add(Pair(key, score))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        list
    }

    TacticalCard(modifier = modifier) {
        Text(
            text = "TACTICAL COHESION HEATMAP (28D HISTORY)",
            style = MaterialTheme.typography.labelSmall,
            color = TacticalGray,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Display blocks divided into 4 columns (weeks) representing 7 days each
            for (week in 0 until 4) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    for (day in 0 until 7) {
                        val index = (week * 7) + day
                        if (index < dates.size) {
                            val score = dates[index].second
                            val blockColor = when {
                                score < 250 -> ThreatRed.copy(alpha = 0.6f)
                                score < 500 -> WarningOrange.copy(alpha = 0.6f)
                                score < 900 -> SecureGreen.copy(alpha = 0.5f)
                                else -> SecureGreen.copy(alpha = 0.9f)
                            }

                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .background(blockColor, RoundedCornerShape(4.dp))
                                    .border(0.5.dp, SteelyBorder, RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
            // Side status checklist panel
            Column(
                modifier = Modifier.weight(1f).padding(start = 16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(SecureGreen, RoundedCornerShape(2.dp)))
                    Text(" Secure (>500)", style = MaterialTheme.typography.labelSmall, color = DisplayWhite, fontSize = 9.sp, modifier = Modifier.padding(start = 4.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(WarningOrange, RoundedCornerShape(2.dp)))
                    Text(" Warning (250-500)", style = MaterialTheme.typography.labelSmall, color = DisplayWhite, fontSize = 9.sp, modifier = Modifier.padding(start = 4.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(ThreatRed, RoundedCornerShape(2.dp)))
                    Text(" Compromised (<250)", style = MaterialTheme.typography.labelSmall, color = DisplayWhite, fontSize = 9.sp, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }
    }
}
