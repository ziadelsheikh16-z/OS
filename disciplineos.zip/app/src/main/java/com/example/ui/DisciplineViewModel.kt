package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.*
import com.example.data.DisciplinePreferences
import com.example.repository.DisciplineRepository
import com.example.utils.DisciplineNotificationManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class DisciplineViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val prefs = DisciplinePreferences(application)
    private val repository = DisciplineRepository(database, prefs)
    private val scheduler = DisciplineNotificationManager(application)

    // Streams from Repository
    val currentStreak = repository.currentStreak.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val longestStreak = repository.longestStreak.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val extremeStrictMode = repository.extremeStrictMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val punishmentSeverity = repository.punishmentSeverity.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "MEDIUM")
    val rewardMultiplier = repository.rewardMultiplier.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.0f)
    val disciplineScore = repository.disciplineScore.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 100)
    val onboarded = repository.onboarded.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val allRoutines = repository.allRoutines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allHabits = repository.allHabits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allPenalties = repository.allPenalties.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allDailyStats = repository.allDailyStats.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allAchievements = repository.allAchievements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state holder for errors and direct warnings
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    init {
        viewModelScope.launch {
            // Check for initial setup, seed DB
            repository.insertInitialData()
            // Check if day rolled over & penalties should be evaluated
            repository.checkAndPerformDailyReset()
        }
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun calculateDisciplineLevel(score: Int): String {
        return repository.calculateDisciplineLevel(score)
    }

    fun getTasksForRoutine(routineId: Int): Flow<List<RoutineTask>> {
        return repository.getTasksForRoutine(routineId)
    }

    fun getMotivationalMessage(level: String, score: Int, completionRate: Float): Pair<String, String> {
        return when {
            score < 100 -> Pair("DISCIPLINE CRITICAL COLLAPSE", "The host has surrendered to base desires. Recover immediately.")
            score < 250 -> Pair("STATUS: DEFICIENT", "Operational resilience is unstable. Stop cutting corners.")
            score < 500 -> Pair("AVERAGE THRESHOLD", "You look like everyone else. Strive for superiority.")
            score < 800 -> Pair("OBJECTIVES STABILIZED", "Tactical cohesion established. Keep holding the line.")
            score < 1200 -> Pair("HIGH PERFORMANCE", "Operational performance is elite. Focus on pure execution.")
            else -> Pair("MONSTER DISCIPLINE", "The digital commander salutes you. Absolute tactical dominance.")
        }
    }

    // Complete / Rescind Task completion
    fun toggleTaskCompletion(task: RoutineTask, isCompleted: Boolean) {
        viewModelScope.launch {
            try {
                repository.completeTask(task, isCompleted)
                if (isCompleted) {
                    scheduler.sendNotification("OBJECTIVE SECURED", "Task '${task.title}' completed successfully. +${task.pointsReward} Rating.")
                }
            } catch (e: Exception) {
                _uiMessage.value = e.message
                scheduler.sendNotification("CONSTRAINT BREACH", e.message ?: "Task execution sequence blocked.")
            }
        }
    }

    // Log a slip-up
    fun logHabitIncident(habit: Habit) {
        viewModelScope.launch {
            repository.logHabitViolation(habit)
            scheduler.sendNotification("VIOLATION REGISTERED", "Incised slip-up of '${habit.name}'. penalty applied.")
        }
    }

    // Settings adjustments
    fun updateSystemSettings(strictMode: Boolean, severity: String, multiplier: Float, forceReset: Boolean) {
        viewModelScope.launch {
            repository.updateSettings(strictMode, severity, multiplier, forceReset)
            _uiMessage.value = if (forceReset) "DATABASE PURGED. INITIAL RE-CALIBRATION SECURED." else "SYSTEM PARAMETERS STABILIZED."
        }
    }

    // Create custom routines
    fun createRoutine(name: String, activeDays: String, category: String, isStrict: Boolean, tasksList: List<Triple<String, Int, Int>>) {
        viewModelScope.launch {
            val routineId = repository.addRoutine(name, activeDays, category, isStrict)
            tasksList.forEachIndexed { index, triple ->
                // Triple(Title, Duration, Reward)
                repository.addTask(
                    routineId = routineId,
                    title = triple.first,
                    durationMinutes = triple.second,
                    points = triple.third,
                    penalty = (triple.third * 1.5).toInt(),
                    category = category,
                    icon = when(category.lowercase()) {
                        "morning" -> "bed"
                        "focus" -> "computer"
                        "physical" -> "fitness_center"
                        else -> "assignment"
                    },
                    deadline = "23:59",
                    order = index
                )
            }
            _uiMessage.value = "ROUTINE '$name' ESTABLISHED IN COMMAND MODULE."
        }
    }

    // Delete Routine
    fun deleteRoutine(routine: Routine) {
        viewModelScope.launch {
            repository.deleteRoutine(routine)
            _uiMessage.value = "ROUTINE DIRECTIVE PURGED."
        }
    }

    // Create Custom Bad Habit
    fun createHabit(name: String, penaltyPoints: Int, category: String) {
        viewModelScope.launch {
            repository.addHabit(name, penaltyPoints, category)
            _uiMessage.value = "BAD HABIT '$name' ENROLLED FOR MONITORING."
        }
    }

    // Delete custom bad habit
    fun deleteHabit(habit: Habit) {
        viewModelScope.launch {
            repository.deleteHabit(habit)
            _uiMessage.value = "MONITORING LOG DEACTIVATED."
        }
    }

    // Set Onboarded
    fun completeOnboarding() {
        viewModelScope.launch {
            prefs.setOnboarded(true)
        }
    }

    // Re-seed routines database with presets
    fun triggerManualPresetSeed() {
        viewModelScope.launch {
            repository.insertInitialData()
            _uiMessage.value = "DEFAULT OPERATIONS DEPLOYED."
        }
    }
}
