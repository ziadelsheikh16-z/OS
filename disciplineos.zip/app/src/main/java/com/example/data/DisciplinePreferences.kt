package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "discipline_settings")

class DisciplinePreferences(private val context: Context) {
    companion object {
        val CURRENT_STREAK = intPreferencesKey("current_streak")
        val LONGEST_STREAK = intPreferencesKey("longest_streak")
        val EXTREME_STRICT_MODE = booleanPreferencesKey("extreme_strict_mode")
        val PUNISHMENT_SEVERITY = stringPreferencesKey("punishment_severity") // "LOW", "MEDIUM", "SEVERE"
        val OFFBOARDED = booleanPreferencesKey("user_onboarded")
        val REWARD_MULTIPLIER = floatPreferencesKey("reward_multiplier")
        val DISCIPLINE_SCORE = intPreferencesKey("discipline_score")
        val LAST_RESET_DAY = stringPreferencesKey("last_reset_day") // For daily resets
    }

    val currentStreak: Flow<Int> = context.dataStore.data.map { it[CURRENT_STREAK] ?: 0 }
    val longestStreak: Flow<Int> = context.dataStore.data.map { it[LONGEST_STREAK] ?: 0 }
    val extremeStrictMode: Flow<Boolean> = context.dataStore.data.map { it[EXTREME_STRICT_MODE] ?: false }
    val punishmentSeverity: Flow<String> = context.dataStore.data.map { it[PUNISHMENT_SEVERITY] ?: "MEDIUM" }
    val onboarded: Flow<Boolean> = context.dataStore.data.map { it[OFFBOARDED] ?: false }
    val rewardMultiplier: Flow<Float> = context.dataStore.data.map { it[REWARD_MULTIPLIER] ?: 1.0f }
    val disciplineScore: Flow<Int> = context.dataStore.data.map { it[DISCIPLINE_SCORE] ?: 100 }
    val lastResetDay: Flow<String?> = context.dataStore.data.map { it[LAST_RESET_DAY] }

    suspend fun setOnboarded(value: Boolean) {
        context.dataStore.edit { it[OFFBOARDED] = value }
    }

    suspend fun updateStreak(streak: Int) {
        context.dataStore.edit { preferences ->
            preferences[CURRENT_STREAK] = streak
            val longest = preferences[LONGEST_STREAK] ?: 0
            if (streak > longest) {
                preferences[LONGEST_STREAK] = streak
            }
        }
    }

    suspend fun setStrictMode(enabled: Boolean) {
        context.dataStore.edit { it[EXTREME_STRICT_MODE] = enabled }
    }

    suspend fun setPunishmentSeverity(severity: String) {
        context.dataStore.edit { it[PUNISHMENT_SEVERITY] = severity }
    }

    suspend fun setRewardMultiplier(multiplier: Float) {
        context.dataStore.edit { it[REWARD_MULTIPLIER] = multiplier }
    }

    suspend fun setDisciplineScore(score: Int) {
        context.dataStore.edit { it[DISCIPLINE_SCORE] = score.coerceIn(0, 5000) }
    }

    suspend fun incrementDisciplineScore(points: Int) {
        context.dataStore.edit { preferences ->
            val current = preferences[DISCIPLINE_SCORE] ?: 100
            preferences[DISCIPLINE_SCORE] = (current + points).coerceIn(0, 5000)
        }
    }

    suspend fun decrementDisciplineScore(points: Int) {
        context.dataStore.edit { preferences ->
            val current = preferences[DISCIPLINE_SCORE] ?: 100
            preferences[DISCIPLINE_SCORE] = (current - points).coerceIn(0, 5000)
        }
    }

    suspend fun setLastResetDay(day: String) {
        context.dataStore.edit { it[LAST_RESET_DAY] = day }
    }
}
