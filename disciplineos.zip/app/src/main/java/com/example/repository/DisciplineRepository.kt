package com.example.repository

import com.example.database.*
import com.example.data.DisciplinePreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class DisciplineRepository(
    private val database: AppDatabase,
    private val prefs: DisciplinePreferences
) {
    val routineDao = database.routineDao()
    val routineTaskDao = database.routineTaskDao()
    val habitDao = database.habitDao()
    val penaltyLogDao = database.penaltyLogDao()
    val dailyStatsDao = database.dailyStatsDao()
    val achievementDao = database.achievementDao()

    // Preferences Flows
    val currentStreak: Flow<Int> = prefs.currentStreak
    val longestStreak: Flow<Int> = prefs.longestStreak
    val extremeStrictMode: Flow<Boolean> = prefs.extremeStrictMode
    val punishmentSeverity: Flow<String> = prefs.punishmentSeverity
    val rewardMultiplier: Flow<Float> = prefs.rewardMultiplier
    val disciplineScore: Flow<Int> = prefs.disciplineScore
    val onboarded: Flow<Boolean> = prefs.onboarded

    // DB Flows
    val allRoutines: Flow<List<Routine>> = routineDao.getAllRoutines()
    val allHabits: Flow<List<Habit>> = habitDao.getAllHabits()
    val allPenalties: Flow<List<PenaltyLog>> = penaltyLogDao.getAllPenalties()
    val allDailyStats: Flow<List<DailyStats>> = dailyStatsDao.getAllStats()
    val allAchievements: Flow<List<Achievement>> = achievementDao.getAllAchievements()

    fun getTasksForRoutine(routineId: Int): Flow<List<RoutineTask>> {
        return routineTaskDao.getTasksForRoutine(routineId)
    }

    private fun getCurrentDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    // Initialize Default Data if empty
    suspend fun insertInitialData() {
        val routines = allRoutines.first()
        if (routines.isEmpty()) {
            val morningId = routineDao.insertRoutine(
                Routine(name = "Morning Combat Init", isStrict = true, activeDays = "Mon,Tue,Wed,Thu,Fri,Sat,Sun", category = "Morning Ritual")
            ).toInt()

            routineTaskDao.insertTask(
                RoutineTask(routineId = morningId, title = "Tactical Wakeup & Bed Made", durationMinutes = 10, pointsReward = 15, penaltyPoints = 30, category = "Hygiene", iconName = "bed", deadlineTime = "06:15", orderIndex = 0)
            )
            routineTaskDao.insertTask(
                RoutineTask(routineId = morningId, title = "Physical Conditioning", durationMinutes = 20, pointsReward = 25, penaltyPoints = 20, category = "Physical", iconName = "fitness_center", deadlineTime = "06:40", orderIndex = 1)
            )
            routineTaskDao.insertTask(
                RoutineTask(routineId = morningId, title = "Deep Focus Planning", durationMinutes = 15, pointsReward = 20, penaltyPoints = 15, category = "Focus", iconName = "assignment", deadlineTime = "07:00", orderIndex = 2)
            )

            // General Focus Routine
            val workId = routineDao.insertRoutine(
                Routine(name = "Deep Focus Blocks", isStrict = false, activeDays = "Mon,Tue,Wed,Thu,Fri", category = "Focus Ritual")
            ).toInt()

            routineTaskDao.insertTask(
                RoutineTask(routineId = workId, title = "90-Min Deep Work executing principal target", durationMinutes = 90, pointsReward = 50, penaltyPoints = 40, category = "Focus", iconName = "computer", deadlineTime = "11:30", orderIndex = 0)
            )
            routineTaskDao.insertTask(
                RoutineTask(routineId = workId, title = "Systems Architecture Audit", durationMinutes = 30, pointsReward = 30, penaltyPoints = 15, category = "Mind", iconName = "analytics", deadlineTime = "12:15", orderIndex = 1)
            )

            // Evening Drill
            val eveningId = routineDao.insertRoutine(
                Routine(name = "Evening Debrief", isStrict = true, activeDays = "Mon,Tue,Wed,Thu,Fri,Sat,Sun", category = "Rest Execution")
            ).toInt()

            routineTaskDao.insertTask(
                RoutineTask(routineId = eveningId, title = "Digital Shutdown", durationMinutes = 15, pointsReward = 15, penaltyPoints = 25, category = "Mind", iconName = "power_settings_new", deadlineTime = "21:30", orderIndex = 0)
            )
            routineTaskDao.insertTask(
                RoutineTask(routineId = eveningId, title = "Self-Evaluation Log", durationMinutes = 10, pointsReward = 15, penaltyPoints = 15, category = "Mind", iconName = "rate_review", deadlineTime = "22:00", orderIndex = 1)
            )

            // Default Bad habits
            habitDao.insertHabit(Habit(name = "Social Media Mindless Scrolling", penaltyPoints = 25, category = "Wasting Time"))
            habitDao.insertHabit(Habit(name = "Junk Food / Sugary Consumables", penaltyPoints = 20, category = "Health Slip"))
            habitDao.insertHabit(Habit(name = "Snoozing Wakeup Alarm", penaltyPoints = 30, category = "Defiance"))
            habitDao.insertHabit(Habit(name = "Procrastinating Primary Target", penaltyPoints = 40, category = "Defiance"))

            // Achievements
            val initialAchievements = listOf(
                Achievement("FIRST_BLOOD", "Slayer Initiate", "Execute your first task with complete adherence.", false, 0L, "military_tech"),
                Achievement("STREAK_3", "Tactical Operational Habit", "Maintain a 3-day active streak.", false, 0L, "star"),
                Achievement("STREAK_7", "Elite Commando", "Maintain a 7-day active streak. Discipline is settling in.", false, 0L, "shield"),
                Achievement("PERFECT_DAY", "Mission Accomplished", "Complete all tasks in a strict routine without a single violation.", false, 0L, "victory_堅"),
                Achievement("ZERO_SLIPS", "Iron Wall", "Log zero bad habits for 3 consecutive days.", false, 0L, "lock"),
                Achievement("MONSTER_SCORE", "Commander Rank", "Reach a total discipline rating of 1000 points.", false, 0L, "bolt")
            )
            achievementDao.insertAchievements(initialAchievements)
        }
    }

    // Execute Daily Reset checks (checks if date changed, resets completions, applies skipped routine penalties)
    suspend fun checkAndPerformDailyReset() {
        val today = getCurrentDateString()
        val lastReset = prefs.lastResetDay.first()

        if (lastReset != today) {
            // Apply skipped penalties if any strict task is incomplete
            val routines = allRoutines.first()
            var penaltyApplied = 0
            
            for (routine in routines) {
                if (routine.isStrict) {
                    val tasks = routineTaskDao.getTasksForRoutineSync(routine.id)
                    val incompleteTasks = tasks.filter { !it.isCompletedToday }
                    for (task in incompleteTasks) {
                        penaltyApplied += task.penaltyPoints
                        penaltyLogDao.insertPenalty(
                            PenaltyLog(
                                reason = "Routine '${routine.name}' incomplete: Task '${task.title}' deadline missed.",
                                pointsDeducted = task.penaltyPoints
                            )
                        )
                    }
                }
            }

            if (penaltyApplied > 0) {
                // Reduce scorecard
                prefs.decrementDisciplineScore(penaltyApplied)
                // Decrease streak to 0 if they failed strict tasks
                prefs.updateStreak(0)
            } else {
                // If they completed at least 1 task or had no strict failures, we keep or increase streak
                val score = prefs.disciplineScore.first()
                if (score > 150) {
                    val currentStr = prefs.currentStreak.first()
                    prefs.updateStreak(currentStr + 1)
                }
            }

            // Perform hard reset of completions
            routineDao.resetAllRoutinesCompletion(false)
            routineTaskDao.resetAllTasksCompletion(false)
            habitDao.resetAllHabitsCompletion()

            // Update stats history
            val currentScore = prefs.disciplineScore.first()
            val completedCount = 0 // resets
            val level = calculateDisciplineLevel(currentScore)
            
            dailyStatsDao.insertStats(
                DailyStats(
                    date = today,
                    score = currentScore,
                    tasksCompleted = completedCount,
                    violationsCount = 0,
                    disciplineLevel = level
                )
            )

            prefs.setLastResetDay(today)
        }
    }

    // Complete / Uncomplete a Task
    suspend fun completeTask(task: RoutineTask, isCompleted: Boolean) {
        val today = getCurrentDateString()
        
        // Check if strict constraint applies: if strict mode is ON, next tasks are locked until preceding is complete
        if (isCompleted) {
            val routine = routineDao.getRoutineById(task.routineId)
            if (routine != null && routine.isStrict) {
                val allTasks = routineTaskDao.getTasksForRoutineSync(task.routineId)
                val precedingIncomplete = allTasks.filter { it.orderIndex < task.orderIndex && !it.isCompletedToday }
                if (precedingIncomplete.isNotEmpty()) {
                    // Preceding tasks must be completed first
                    throw IllegalStateException("STRICT CONSTRAINT: You must execute task '${precedingIncomplete.first().title}' first.")
                }
            }
        }

        // Toggle task completion
        routineTaskDao.setTaskCompletion(task.id, isCompleted)

        // Adjust points
        val multiplier = prefs.rewardMultiplier.first()
        val calculatedPoints = (task.pointsReward * multiplier).toInt()

        if (isCompleted) {
            prefs.incrementDisciplineScore(calculatedPoints)
            triggerAchievementCheck("FIRST_BLOOD")

            // Update stats
            val currentStats = dailyStatsDao.getStatsByDate(today) ?: DailyStats(today)
            dailyStatsDao.insertStats(
                currentStats.copy(
                    score = (currentStats.score + calculatedPoints).coerceIn(0, 5000),
                    tasksCompleted = currentStats.tasksCompleted + 1
                )
            )

            // Check if routine fully complete
            val routineTasks = routineTaskDao.getTasksForRoutineSync(task.routineId)
            val allComplete = routineTasks.all { it.isCompletedToday || it.id == task.id }
            if (allComplete) {
                val routine = routineDao.getRoutineById(task.routineId)
                if (routine != null) {
                    routineDao.updateRoutine(routine.copy(isCompletedToday = true))
                    // Perfect routine completion bonus
                    prefs.incrementDisciplineScore(20)
                    triggerAchievementCheck("PERFECT_DAY")
                }
            }
        } else {
            prefs.decrementDisciplineScore(calculatedPoints)
            
            // Update stats
            val currentStats = dailyStatsDao.getStatsByDate(today) ?: DailyStats(today)
            dailyStatsDao.insertStats(
                currentStats.copy(
                    score = (currentStats.score - calculatedPoints).coerceIn(0, 5000),
                    tasksCompleted = (currentStats.tasksCompleted - 1).coerceAtLeast(0)
                )
            )
        }

        // Ensure current day stats is saved correctly
        saveCurrentDayStats()
        evaluateMilestones()
    }

    // Log Habit Violation
    suspend fun logHabitViolation(habit: Habit) {
        val today = getCurrentDateString()
        
        // Log penalty details
        val severity = prefs.punishmentSeverity.first()
        val severityMultiplier = when (severity) {
            "LOW" -> 0.5f
            "MEDIUM" -> 1.0f
            "SEVERE" -> 1.8f
            else -> 1.0f
        }
        val computedPenalty = (habit.penaltyPoints * severityMultiplier).toInt()

        // Apply penalty
        prefs.decrementDisciplineScore(computedPenalty)
        penaltyLogDao.insertPenalty(
            PenaltyLog(reason = "Violation logged: ${habit.name}", pointsDeducted = computedPenalty)
        )

        // Decrease streak strength on heavy violation
        val currentStr = prefs.currentStreak.first()
        if (severity == "SEVERE") {
            prefs.updateStreak((currentStr / 2).coerceAtLeast(0))
        } else {
            prefs.updateStreak((currentStr - 1).coerceAtLeast(0))
        }

        // Update database habit trackers
        habitDao.updateHabit(
            habit.copy(
                timesViolatedToday = habit.timesViolatedToday + 1,
                totalViolations = habit.totalViolations + 1,
                lastViolatedTimestamp = System.currentTimeMillis()
            )
        )

        // Update daily stats
        val currentStats = dailyStatsDao.getStatsByDate(today) ?: DailyStats(today)
        dailyStatsDao.insertStats(
            currentStats.copy(
                score = (currentStats.score - computedPenalty).coerceIn(0, 5000),
                violationsCount = currentStats.violationsCount + 1,
                disciplineLevel = calculateDisciplineLevel(prefs.disciplineScore.first())
            )
        )

        saveCurrentDayStats()
        evaluateMilestones()
    }

    // Save Daily Summary explicitly
    suspend fun saveCurrentDayStats() {
        val today = getCurrentDateString()
        val score = prefs.disciplineScore.first()
        val level = calculateDisciplineLevel(score)
        val currentStats = dailyStatsDao.getStatsByDate(today) ?: DailyStats(today)
        
        dailyStatsDao.insertStats(
            currentStats.copy(
                score = score,
                disciplineLevel = level
            )
        )
    }

    // Calculate level based on score
    fun calculateDisciplineLevel(score: Int): String {
        return when {
            score < 100 -> "Weak"
            score < 250 -> "Unstable"
            score < 500 -> "Average"
            score < 800 -> "Focused"
            score < 1200 -> "Disciplined"
            score < 2000 -> "Elite"
            else -> "Monster Discipline"
        }
    }

    // Evaluate stats for achievements
    suspend fun evaluateMilestones() {
        val score = prefs.disciplineScore.first()
        val streak = prefs.currentStreak.first()

        if (score >= 1000) {
            triggerAchievementCheck("MONSTER_SCORE")
        }
        if (streak >= 3) {
            triggerAchievementCheck("STREAK_3")
        }
        if (streak >= 7) {
            triggerAchievementCheck("STREAK_7")
        }
    }

    private suspend fun triggerAchievementCheck(id: String) {
        val achievements = allAchievements.first()
        val target = achievements.find { it.id == id }
        if (target != null && !target.isUnlocked) {
            achievementDao.updateAchievementUnlockStatus(id, true, System.currentTimeMillis())
        }
    }

    // Helper functions for Routine Management
    suspend fun addRoutine(name: String, activeDays: String, category: String, isStrict: Boolean): Int {
        return routineDao.insertRoutine(
            Routine(name = name, isStrict = isStrict, activeDays = activeDays, category = category)
        ).toInt()
    }

    suspend fun deleteRoutine(routine: Routine) {
        routineDao.deleteRoutine(routine)
    }

    suspend fun addTask(routineId: Int, title: String, durationMinutes: Int, points: Int, penalty: Int, category: String, icon: String, deadline: String, order: Int) {
        routineTaskDao.insertTask(
            RoutineTask(
                routineId = routineId,
                title = title,
                durationMinutes = durationMinutes,
                pointsReward = points,
                penaltyPoints = penalty,
                category = category,
                iconName = icon,
                deadlineTime = deadline,
                orderIndex = order
            )
        )
    }

    suspend fun deleteTask(task: RoutineTask) {
        routineTaskDao.deleteTask(task)
    }

    suspend fun addHabit(name: String, penaltyPoints: Int, category: String) {
        habitDao.insertHabit(
            Habit(name = name, penaltyPoints = penaltyPoints, category = category)
        )
    }

    suspend fun deleteHabit(habit: Habit) {
        habitDao.deleteHabit(habit)
    }

    suspend fun updateSettings(strictMode: Boolean, severity: String, rewardMult: Float, resetScore: Boolean) {
        prefs.setStrictMode(strictMode)
        prefs.setPunishmentSeverity(severity)
        prefs.setRewardMultiplier(rewardMult)
        if (resetScore) {
            prefs.setDisciplineScore(100)
            prefs.updateStreak(0)
            penaltyLogDao.clearAllPenalties()
            dailyStatsDao.clearAllStats()
        }
    }
}
