package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routines")
data class Routine(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val isStrict: Boolean,
    val activeDays: String, // e.g., "Mon,Tue,Wed,Thu,Fri,Sat,Sun"
    val category: String, // e.g., "Morning Ritual", "Focus Ritual", "Rest Execution"
    val isCompletedToday: Boolean = false
)

@Entity(tableName = "routine_tasks")
data class RoutineTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val routineId: Int,
    val title: String,
    val durationMinutes: Int,
    val pointsReward: Int,
    val penaltyPoints: Int,
    val category: String,
    val iconName: String, // Material Icon name string
    val deadlineTime: String, // e.g. "08:30"
    val isCompletedToday: Boolean = false,
    val orderIndex: Int
)

@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val penaltyPoints: Int,
    val timesViolatedToday: Int = 0,
    val totalViolations: Int = 0,
    val lastViolatedTimestamp: Long = 0L,
    val category: String = "Habit"
)

@Entity(tableName = "penalty_logs")
data class PenaltyLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val reason: String,
    val pointsDeducted: Int
)

@Entity(tableName = "daily_stats")
data class DailyStats(
    @PrimaryKey val date: String, // "yyyy-MM-dd"
    val score: Int = 100, // starts at 100, goes down for penalties, up for accomplishments
    val tasksCompleted: Int = 0,
    val violationsCount: Int = 0,
    val disciplineLevel: String = "Average"
)

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val isUnlocked: Boolean = false,
    val unlockedTimestamp: Long = 0L,
    val iconName: String
)
