package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutineDao {
    @Query("SELECT * FROM routines ORDER BY id ASC")
    fun getAllRoutines(): Flow<List<Routine>>

    @Query("SELECT * FROM routines WHERE id = :id")
    suspend fun getRoutineById(id: Int): Routine?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: Routine): Long

    @Update
    suspend fun updateRoutine(routine: Routine)

    @Delete
    suspend fun deleteRoutine(routine: Routine)
    
    @Query("UPDATE routines SET isCompletedToday = :completed")
    suspend fun resetAllRoutinesCompletion(completed: Boolean)
}

@Dao
interface RoutineTaskDao {
    @Query("SELECT * FROM routine_tasks WHERE routineId = :routineId ORDER BY orderIndex ASC")
    fun getTasksForRoutine(routineId: Int): Flow<List<RoutineTask>>

    @Query("SELECT * FROM routine_tasks WHERE routineId = :routineId ORDER BY orderIndex ASC")
    suspend fun getTasksForRoutineSync(routineId: Int): List<RoutineTask>

    @Query("SELECT * FROM routine_tasks ORDER BY orderIndex ASC")
    fun getAllTasks(): Flow<List<RoutineTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: RoutineTask): Long

    @Update
    suspend fun updateTask(task: RoutineTask)

    @Delete
    suspend fun deleteTask(task: RoutineTask)

    @Query("UPDATE routine_tasks SET isCompletedToday = :completed")
    suspend fun resetAllTasksCompletion(completed: Boolean)
    
    @Query("UPDATE routine_tasks SET isCompletedToday = :completed WHERE id = :taskId")
    suspend fun setTaskCompletion(taskId: Int, completed: Boolean)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY name ASC")
    fun getAllHabits(): Flow<List<Habit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: Habit): Long

    @Update
    suspend fun updateHabit(habit: Habit)

    @Delete
    suspend fun deleteHabit(habit: Habit)

    @Query("UPDATE habits SET timesViolatedToday = 0")
    suspend fun resetAllHabitsCompletion()
}

@Dao
interface PenaltyLogDao {
    @Query("SELECT * FROM penalty_logs ORDER BY timestamp DESC")
    fun getAllPenalties(): Flow<List<PenaltyLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPenalty(log: PenaltyLog): Long

    @Query("DELETE FROM penalty_logs")
    suspend fun clearAllPenalties()
}

@Dao
interface DailyStatsDao {
    @Query("SELECT * FROM daily_stats ORDER BY date DESC")
    fun getAllStats(): Flow<List<DailyStats>>

    @Query("SELECT * FROM daily_stats WHERE date = :date")
    suspend fun getStatsByDate(date: String): DailyStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStats(stats: DailyStats)

    @Query("DELETE FROM daily_stats")
    suspend fun clearAllStats()
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Query("UPDATE achievements SET isUnlocked = :unlocked, unlockedTimestamp = :timestamp WHERE id = :id")
    suspend fun updateAchievementUnlockStatus(id: String, unlocked: Boolean, timestamp: Long)
}
